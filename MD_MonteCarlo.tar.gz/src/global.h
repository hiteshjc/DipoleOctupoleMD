#ifndef GLOBAL_H
#define GLOBAL_H

#include<iostream>
#include<stdio.h>
#include<fstream>
#include<sstream>
#include<vector>
#include<string>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<wchar.h>
#include<cwchar>
#include<boost/lexical_cast.hpp>
#include<boost/function.hpp>
#include<boost/format.hpp>
#include<complex>
#include<iomanip>
#include<ctime>
#include"matrix.h"
#include<omp.h>
#include<bitset>
#include"stensor.h"

#endif
